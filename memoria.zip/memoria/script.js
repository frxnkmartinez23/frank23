// script.js
const images = [
    'images/adewuawi.jpg', 'images/frank1.jpg', 
    'images/chino.jpg', 'images/juni2.jpg',
    'images/wilfred.jpg', 'images/frank2.webp', 
    'images/jesvi.jpg', 'images/juni1.jpg'
  ];
  
  
  const gameContainer = document.querySelector('.memory-game');
  const messageContainer = document.querySelector('.message-container');
  const restartBtn = document.querySelector('.restart-btn');
  let cards = [...images, ...images];
  let matchedCards = 0;
  
  // Barajar las cartas
  cards.sort(() => 0.5 - Math.random());
  
  // Crear las cartas
  cards.forEach(image => {
    const card = document.createElement('div');
    card.classList.add('memory-card');
    card.innerHTML = `
      <div class="front">
        <img src="${image}" alt="" style="width: 100%; height: 100%; object-fit: cover;">
      </div>
      <div class="back"></div>
    `;
    gameContainer.appendChild(card);
  });
  
  let hasFlippedCard = false;
  let lockBoard = false;
  let firstCard, secondCard;
  
  function flipCard() {
    if (lockBoard) return;
    if (this === firstCard) return;
  
    this.classList.add('flip');
  
    if (!hasFlippedCard) {
      hasFlippedCard = true;
      firstCard = this;
      return;
    }
  
    secondCard = this;
    checkForMatch();
  }
  
  function checkForMatch() {
    const isMatch = firstCard.innerHTML === secondCard.innerHTML;
    isMatch ? disableCards() : unflipCards();
  }
  
  function disableCards() {
    firstCard.removeEventListener('click', flipCard);
    secondCard.removeEventListener('click', flipCard);
  
    matchedCards += 2;
    if (matchedCards === cards.length) {
      setTimeout(() => {
        showVictoryMessage();
      }, 500);
    }
  
    resetBoard();
  }
  
  function unflipCards() {
    lockBoard = true;
  
    setTimeout(() => {
      firstCard.classList.remove('flip');
      secondCard.classList.remove('flip');
  
      resetBoard();
    }, 1500);
  }
  
  function resetBoard() {
    [hasFlippedCard, lockBoard] = [false, false];
    [firstCard, secondCard] = [null, null];
  }
  
  function showVictoryMessage() {
    messageContainer.classList.remove('hidden');
  }
  
  function restartGame() {
    gameContainer.innerHTML = '';
    matchedCards = 0;
    messageContainer.classList.add('hidden');
  
    // Barajar y recrear cartas
    cards.sort(() => 0.5 - Math.random());
    cards.forEach(image => {
      const card = document.createElement('div');
      card.classList.add('memory-card');
      card.innerHTML = `
        <div class="front">
          <img src="${image}" alt="" style="width: 100%; height: 100%; object-fit: cover;">
        </div>
        <div class="back"></div>
      `;
      gameContainer.appendChild(card);
    });
  
    document.querySelectorAll('.memory-card').forEach(card => {
      card.addEventListener('click', flipCard);
    });
  }
  
  document.querySelectorAll('.memory-card').forEach(card => {
    card.addEventListener('click', flipCard);
  });
  
  restartBtn.addEventListener('click', restartGame);